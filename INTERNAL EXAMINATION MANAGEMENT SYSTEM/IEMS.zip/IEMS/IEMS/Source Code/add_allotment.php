<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>

 <?php
 include('connect.php');
 date_default_timezone_set('Asia/Kolkata');
 $current_date = date('Y-m-d');

?>

        <div class="page-wrapper">
           
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">Teacher Allotment Management</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Allotment Management</li>
                    </ol>
                </div>
            </div>
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-8" style="margin-left: 10%;">
                        <div class="card">
                            <div class="card-body">
                                <div class="input-states">
                                    <form class="form-horizontal" method="POST" action="pages/save_teacherallotment.php" name="userform" enctype="multipart/form-data">
            <!-- <div class="form-group">
                    <div class="row">
                        <label class="col-sm-3 control-label">Department</label>
                        <div class="col-sm-9">
                            <select type="text" name="dept" id="class_id" class="form-control"   placeholder="Department" required="">
                                <option value="">--Select Department--</option>
                                    <?php  
                                    $c1 = "SELECT * FROM `tbl_department`";
                                    $result = $conn->query($c1);
                                    while ($row = mysqli_fetch_array($result)) {
                                        $s1 = "SELECT count(*) as qty FROM `tbl_student` WHERE classname='".$row["id"]."'";
                                        $sr = $conn->query($s1);
                                        if ($sr->num_rows > 0) {
                                            $sres = mysqli_fetch_array($sr);
                                            $qty=$sres['qty'];
                                        }
                                        else
                                        {
                                            $qty=0;
                                        }
                                     ?>
                                            <option value="<?php echo $row["id"];?>" data-capacity="<?php echo $qty; ?>">
                                                <?php echo $row['classname'];?>
                                            </option>
                                            <?php
                                        }
                                    ?>
                            </select>
                        </div>
                    </div>
                </div> -->
                <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Department</label>
                                                <div class="col-sm-9">
                                                    <select type="text" name="dept" id="Did" class="form-control"   placeholder="Department" required="">
                                                        <option value="">--Select Dept--</option>
                                                            <?php  
                                                            $c1 = "SELECT * FROM `tbl_department`";
                                                            $result = $conn->query($c1);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {?>
                                                                    <option value="<?php echo $row["Did"];?>">
                                                                        <?php echo $row['dept'];?>
                                                                    </option>
                                                                    <?php
                                                                }
                                                            } else {
                                                            echo "0 results";
                                                                }
                                                            ?>
                                                    </select>
                                                </div>
                                            </div>
                                            

                                            <div class="row">
                        <label class="col-sm-3 control-label">Subject</label>
                        <div class="col-sm-9">
                            <select type="text" name="subject" id="subject_id" class="form-control"   placeholder="Subject" required="">
                                <option value="">--Select Subject--</option>
                                    <?php  
                                    $c1 = "SELECT * FROM `tbl_subject`";
                                    $result = $conn->query($c1);

                                    if ($result->num_rows > 0) {
                                        while ($row = mysqli_fetch_array($result)) {?>
                                                <option value="<?php echo $row["id"];?>">

<!--                                             <option value="<?php echo $row["id"];?>" style="display: none;" data-id="<?php echo $row["id"];?>">
 -->                                                <?php echo $row['subject'];?>
                                            </option>
                                            <?php
                                        }
                                    } else {
                                    echo "0 results";
                                        }
                                    ?>
                            </select>
                        </div>
                        <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Block</label>
                                                <div class="col-sm-9">
                                                    <select type="text" name="block_name" id="block_id" class="form-control"   placeholder="Block" required="">
                                                        <option value="">--Select Block--</option>
                                                            <?php  
                                                            $c1 = "SELECT * FROM `tbl_block`";
                                                            $result = $conn->query($c1);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {?>
                                                                    <option value="<?php echo $row["block_id"];?>">
                                                                        <?php echo $row['block_name'];?>
                                                                    </option>
                                                                    <?php
                                                                }
                                                            } else {
                                                            echo "0 results";
                                                                }
                                                            ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
            
                
                <!-- <div class="form-group">
                    <div class="row">
                        <label class="col-sm-3 control-label">Room NO</label>
                        <div class="col-sm-9">
                            <select type="text" name="room_type_id" id="room_type_id" class="form-control"   placeholder="Room" required="">
                                <option value="">--Select Room NO--</option>
                                    <?php  
                                    $c1 = "SELECT * FROM `room_type`";
                                    $result = $conn->query($c1);
                                    while ($row = mysqli_fetch_array($result)) {
                                        $s1 = "SELECT SUM(strenght) as qty FROM `room` WHERE type_id='".$row["id"]."'";
                                        $sr = $conn->query($s1);
                                        if ($sr->num_rows > 0) {
                                            $sres = mysqli_fetch_array($sr);
                                            $qty=$sres['qty'];
                                        }
                                        else
                                        {
                                            $qty=0;
                                        }
                                     ?>
                                            <option value="<?php echo $row["id"];?>" data-capacity="<?php echo $qty; ?>">
                                                <?php echo $row['roomname'];?>
                                            </option>
                                            <?php
                                        }
                                    ?>
                            </select>
                        </div>
                    </div>
                </div> -->
                <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Room NO</label>
                                                <div class="col-sm-9">
                                                    <select type="text" name="room_no" class="form-control"  id="Rid" placeholder="Room No" required="">
                                                        <option value="">--Select Room--</option>
                                                            <?php  
                                                            $c1 = "SELECT * FROM `room`";
                                                            $result = $conn->query($c1);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {?>
                                                                    <option value="<?php echo $row["Rid"];?>">
                                                                        <?php echo $row['room_no'];?>
                                                                    </option>
                                                                    <?php
                                                                }
                                                            } else {
                                                            echo "0 results";
                                                                }
                                                            ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
               <!--  <div class="form-group">
                    <div class="row">
                        <label class="col-sm-3 control-label">Exam</label>
                        <div class="col-sm-9">
                            <select type="text" name="exam_id" id="exam_id" class="form-control"   placeholder="Exam" required="">
                                <option value="">--Select Exam--</option>
                                    <?php  
                                    $c1 = "SELECT * FROM `exam`";
                                    $result = $conn->query($c1);
                                        while ($row = mysqli_fetch_array($result)) {?>
                                            <option value="<?php echo $row["id"];?>" style="display: none;" data-id="<?php echo $row["subject_id"];?>">
                                                <?php echo $row['name'];?>
                                            </option>
                                            <?php } ?>
                            </select>
                        </div>
                    </div>
                </div> -->
                <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Date</label>
                                                <div class="col-sm-9">
                                                  <input type="date" name="date" class="form-control" placeholder="Date" id="event" onkeydown="return alphaOnly(event);" required="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Shift</label>
                                                <div class="col-sm-9">
                                                  <input type="text" name="shift" class="form-control" placeholder="Shift" id="event" onkeydown="return alphaOnly(event);" required="">
                                                </div>
                                            </div>
                                        </div>                     
                                        <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Teacher Name</label>
                                                <div class="col-sm-9">
                                                    <select type="text" name="fname" class="form-control"   placeholder="Teacher Name" required="">
                                                        <option value="">--Select Name--</option>
                                                            <?php  
                                                            $c1 = "SELECT * FROM `tbl_teacher`";
                                                            $result = $conn->query($c1);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = mysqli_fetch_array($result)) {?>
                                                                    <option value="<?php echo $row["id"];?>">
                                                                        <?php echo $row['fname'];?>
                                                                    </option>
                                                                    <?php
                                                                }
                                                            } else {
                                                            echo "0 results";
                                                                }
                                                            ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Class Capacity</label>
                                                <div class="col-sm-9">
                                                  <input type="text" name="capacity" id="class_capacity" class="form-control" placeholder="Class Capacity" readonly>
                                                </div>
                                            </div>
                                        </div> -->
                                         <!-- <div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Room Type Capacity</label>
                                                <div class="col-sm-9">
                                                  <input type="text" name="room_capacity" id="room_capacity" class="form-control" placeholder="Room Type Capacity" readonly>
                                                </div>
                                            </div>
                                        </div> -->
                                        <button type="submit" name="btn_save" id="btn_save" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
                
        
<?php include('footer.php');?>

<!-- <script type="text/javascript">
 $('#Did').change(function(){
    var strength=$('#Rid').find(':selected').attr('strength');
    $('#strength').val(class_capacity);
    $("#subject_id").val('');
    $("#subject_id").children('option').hide();
    var Did=$(this).val();
    $("#subject_id").children("option[data-id="+Did+ "]").show();
    
  });
</script>
<script type="text/javascript">
/*  $('#subject_id').change(function(){
    $("#exam_name").val('');
    $("#exam_name").children('option').hide();
    var subject=$(this).val();
    $("#exam_name").children("option[data-id="+subject+ "]").show();

    $("#teacher_fname").val('');
    $("#teacher_fname").children('option').hide();
    $("#teacher_fname").children("option[data-id="+subject+ "]").show();
    
  }); */
 $('#block_id').change(function(){
    var room_capacity=$('#block_id').find(':selected').attr('block_name');
    $('#block_name').val(block_name);
    
  });
 /*  $('#btn_save').click(function(){
    var room_capacity=$('#room_capacity').val();
    var strength=$('#strength').val();
    if(parseInt(strength) > parseInt(room_capacity))
    {
        alert('Students quantity are greater than available room');
        return false;
    }
    else
    {
        return true;
    }

    
  }); */
</script> -->